 #Using "puts" display the result of the following - true of false
puts " Is it true 2 less than 5?", 2 < 5
