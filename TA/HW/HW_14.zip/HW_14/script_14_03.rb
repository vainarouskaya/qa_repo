 #Using "puts" display the following statement and its result
puts "What is 3 + 2?\n3 + 2 is",3 + 2
