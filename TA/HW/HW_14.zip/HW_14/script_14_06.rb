 #Using "print" display how many Roosters
print "Roosters - ", 100 - 25 * 3 % 4
