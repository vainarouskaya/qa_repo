#Using "puts" display the result of the following - true of false
puts "Is it true 5 greater than 10?", 5 > 10
