 #Using "print" display how many Hens 
print "Hens - ", 25 + 30 / 6
