 #Using "puts" display the following statement and its result:
puts "What is 5 - 7?\n5 - 7 is",5 - 7
