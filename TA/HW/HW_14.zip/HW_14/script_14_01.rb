 #Using puts display the following
puts "3 + 2 + 1 - 5 + 4 % 2 - 1 / 4 + 6"
