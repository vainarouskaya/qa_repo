 #Using "print" display the result of the following - true of false
print "3 + 2 < 5 - 7 is ", 3 + 2 < 5 - 7
