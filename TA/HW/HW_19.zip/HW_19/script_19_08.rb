 #Display the first item in the following range: from cab to cat
range = ('cab'..'cat')
puts range.to_a.first
