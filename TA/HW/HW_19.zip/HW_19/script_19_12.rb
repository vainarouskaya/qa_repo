 #Display the size (how many items) in the following range: from a to z
range = 'a'..'z'
puts range.to_a.size
