 #Display the minimum item in the following range: from 1 to 768
range = (1..768)

range.min
puts range.to_a.min

