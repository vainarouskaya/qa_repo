 #Display the maximum item in the following range: from 1 to 768
range = (1..768)
range.max
puts range.to_a.max
