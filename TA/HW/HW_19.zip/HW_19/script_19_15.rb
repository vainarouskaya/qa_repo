 #What is the result If score (nothing)

score = 'nil'

result= case score

when 1..10 then "Fail"
        when 11..20 then "Pass"
else "Invalid score"
end
puts result

#What is the result If score 5

 score = 5

result= case score

when 1..10 then "Fail"
        when 11..20 then "Pass"
else "Invalid score"
end
puts result

#What is the result If score 15
score = 15

result= case score

when 1..10 then "Fail"
        when 11..20 then "Pass"
else "Invalid score"
end
puts result

