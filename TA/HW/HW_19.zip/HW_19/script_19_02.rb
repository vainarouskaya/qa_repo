 #Display the following range excluding end point: from 1 to 10
range = (1...10)

range.class
range.to_a
puts range.to_a

