 #Display the following range: from cab to cat
range = ('cab'..'cat')
range.class
puts range.to_a
