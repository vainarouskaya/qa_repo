 #Display (true of false) if string caw present in the following range: from cab to cat
range = ('cab'..'cat')

if range==='caw'
puts "String caw presents in the raw"
else
puts "String caw doesn't present in the raw"
end
