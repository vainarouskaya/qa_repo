 #Display (true or false) if string cap present in the following range: from cab #to cat
range = ('cab'..'cat')
if range ==='cap'
puts "true"
else
puts "false"
end
