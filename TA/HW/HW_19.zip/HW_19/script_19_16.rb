 #Display if the following range true of false:11 exists in the range from 1 to 10
range = (1..10)
if range===11
puts "11 exists in the range"
else
puts "11 doesn't exist in the range"
end

#Display if the following range true of false:k exists in the range from a to z

range = ('a'..'z')
if range==='k'
puts "k exists in the range"
else
puts "k doesn't exist in the range"
end

#Display if the following range true of false:cat exists in the range from cab to caw

puts ('cab'..'cat')==='caw'

