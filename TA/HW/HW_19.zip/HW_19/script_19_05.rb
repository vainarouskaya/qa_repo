 #Display the following range: from a to z
range = ('a'..'z')
range.class
range.to_a
puts range.to_a
