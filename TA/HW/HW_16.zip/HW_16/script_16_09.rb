 #Display result of the comparison using .eql? operator of following:
#1, 1
#1, 1.0
#qa, qa
puts 1.eql?(1)
puts 1.eql?(1.0)
puts 'qa'.eql?('qa')
