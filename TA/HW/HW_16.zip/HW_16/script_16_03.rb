 #Display result of the comparison using > operator of following variables:  a, b
a=10
b=3
puts a>b
