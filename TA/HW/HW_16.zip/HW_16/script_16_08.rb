 #Display 2 results of the comparison using === operator of following variables in the range 1 to 5: 
#a
#b
a=10
b=3
puts (1..5) === a
puts (1..5) === b
