 #Display object_id and 2 results of the comparison using .equal? operator of following strings and following symbols:
#qa, qa
#:qa, :qa
puts 'qa'.equal?('qa')
puts :qa.equal?(:qa)
