 #Using heredoc and puts to display multiline statement
 puts <<-SOMETHING
This is a multiline statement
	using heredoc 
for each line!
	SOMETHING
