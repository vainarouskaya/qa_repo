 #Using puts display statement
puts "This statement contains \" double quotes"
