 #This is a multiline statement using multiple puts commands for each line
 puts "This is a multiline statement\n"
 puts "\tusing multiple puts commands\n"
 puts "for each line!" 
