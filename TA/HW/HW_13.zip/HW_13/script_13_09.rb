 #Using "puts" display number of characters in statement
puts "This statement contains \" double quote and \' single quote".length
