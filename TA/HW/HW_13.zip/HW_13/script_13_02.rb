 #Returns string without adding a new line
 print "Hello World!"
