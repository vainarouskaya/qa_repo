  #Returns the string and add the new line
 puts "Hello World!"
