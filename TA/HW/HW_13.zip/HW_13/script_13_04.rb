 #This is a multiline statement using one puts command for each line
 puts "This is a multiline statement\n\tusing one puts command\nfor each line!"
