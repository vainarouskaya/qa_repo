 #Using "puts" and * (asterisk) repeat this statement twice
puts "This statement it repeat itself twice!"*2
