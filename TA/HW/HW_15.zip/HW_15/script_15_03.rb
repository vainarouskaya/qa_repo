 #Display result of the multiplication operation using following variables:  a, b
a=10
b=3
puts a * b
