 #Display result of the exponent operation (first variable in power on second variable) using following variables: a, b
a=10
b=3
puts a**b
