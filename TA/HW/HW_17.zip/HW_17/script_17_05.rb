 #Display result of the assignment using /= operator of following variables:  c /= a
a = 10.0
b = 3.0
c ||= 5.0
c /= a
puts c
puts c.to_i

