 #Display result of both conditions (true and false) of the logical operator && using following variables:  a, b
a=10
b=3
#True conditions:
if a==10 && b==3
puts "Correct"
else
puts "Not correct"
end

#False conditions:

if a==10 && b==1
puts "Correct"
else
puts "Not correct"
end
