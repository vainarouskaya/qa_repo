 #Display result of both conditions (true and false) of the logical operator or using following variables:  a, b
#True conditions:
a=10
b=3

if a==10 or b==2
puts "Correct"
else
puts "Not correct"
end
#False conditions:
a=10
b=3
puts "Correct" if a==12 or b==2

