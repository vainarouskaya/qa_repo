 #Display result of both conditions (true and false) of the logical operator ! using following variable:  a
a=10

#True conditions:

if !(a==11)
puts "Correct"
else
puts "Not correct"
end
#False conditions:

if !(a==10)
puts "Correct"
else
puts "Not correct"
end
