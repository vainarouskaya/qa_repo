 #Display result of both conditions (true and false) of the logical operator not using following variables:  a
a=10
#True conditions:

if not(a==13)
puts "Correct"
else
puts "Not correct"
end

#False conditions:

if not(a==10)
puts "Correct"
else
puts "Not correct"
end
