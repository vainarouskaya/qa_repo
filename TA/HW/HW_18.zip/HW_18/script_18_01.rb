 #Display result of both conditions (true and false) of the logical operator and using following variables:  a, b
#True condition:
a=10
b=3
if a==10 and b == 3
puts "Correct"
else
puts "Not correct"
end
#False condition:

a=10
b=3

if a==10 and b==5
puts "Correct"
else 
puts "Not correct"
end

